#maze drive game#

This is a simple car simulation, developed under computer graphics course.
This helps to understand the graphics behavior and game making process.

The game is a driving game which drive in a mountain terrain like structure.
Car has the basic controlls such as accelerating, breaking and turning.
The camera is moving with the car when car moves.

The main UI has two basic buttons as play the game and quit the game.
The game can be also paused and from the resume panel we can resume the game or we can move to the home UI.
The game has two scenes, the game and main menu UI.
The car also have audio source.
when the car accerate the pitch of the sound vary.
  
The car model was downloaded under free license and other object found default.
And some png files and a audio file which are also free to use.


The game no needed to be installed .
We can run the game by double clicking simulation.exe file.
It was build with Unity 2020.

You can play with arrow keys.
upward arrow for accelerate, downward for decelerate, left and right keys for steering the car.
spacebar for break;